import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ProductSection from "@/components/ProductSection";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <ProductSection />
      <footer className="border-t border-border py-8 text-center">
        <p className="text-muted-foreground text-sm">
          © 2026 NIN7 STORE — Todos os direitos reservados
        </p>
      </footer>
    </div>
  );
};

export default Index;
