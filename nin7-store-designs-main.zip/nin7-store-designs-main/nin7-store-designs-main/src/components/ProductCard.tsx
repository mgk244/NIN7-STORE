import { ShoppingCart, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProductCardProps {
  image: string;
  title: string;
  price: string;
  badge?: string;
}

const ProductCard = ({ image, title, price, badge }: ProductCardProps) => {
  return (
    <div className="bg-card rounded-xl overflow-hidden border border-border card-glow transition-transform hover:scale-[1.02]">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={image} alt={title} className="w-full h-full object-cover" />
        {badge && (
          <span className="absolute top-2 left-2 bg-primary/90 text-primary-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">
            {badge}
          </span>
        )}
      </div>
      <div className="p-3">
        <h3 className="font-display font-semibold text-sm text-foreground mb-1">{title}</h3>
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="font-display font-bold text-lg text-primary">{price}</p>
            <p className="text-[11px] text-muted-foreground">À vista no Pix</p>
          </div>
          <button className="p-1.5 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
            <Settings2 className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
        <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-display font-semibold text-sm h-9 gap-2 rounded-lg">
          <ShoppingCart className="w-4 h-4" /> Comprar agora
        </Button>
      </div>
    </div>
  );
};

export default ProductCard;
