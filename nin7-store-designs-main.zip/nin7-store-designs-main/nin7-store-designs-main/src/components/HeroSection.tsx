import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section className="relative py-16 px-4 text-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
      <div className="relative z-10 max-w-lg mx-auto">
        <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground leading-tight mb-4">
          Xits com confiança{" "}
          <span className="text-primary text-glow">7 dias</span> de garantia
        </h2>
        <p className="text-muted-foreground text-base mb-8">
          A melhor loja de Xits com entregas imediatas no WhatsApp, tropa chama!
        </p>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-display font-semibold text-base px-6 py-3 h-auto rounded-full gap-2">
          Ver produtos <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </section>
  );
};

export default HeroSection;
