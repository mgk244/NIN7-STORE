import ProductCard from "./ProductCard";
import product1 from "@/assets/product1.jpg";
import product2 from "@/assets/product2.jpg";
import product3 from "@/assets/product3.jpg";
import product4 from "@/assets/product4.jpg";
import product5 from "@/assets/product5.jpg";
import product6 from "@/assets/product6.jpg";

const sections = [
  {
    title: "PAINÉIS ANDROID 🎯",
    products: [
      { image: product1, title: "FFH4X Android Safe 🔥", price: "R$ 16,00", badge: "POPULAR" },
      { image: product2, title: "Drip Client Android 🔥", price: "R$ 16,00" },
    ],
  },
  {
    title: "HEADSHOT MODS 💀",
    products: [
      { image: product3, title: "HS Pescoço Android", price: "R$ 8,00" },
      { image: product4, title: "HS Peito Android", price: "R$ 10,00", badge: "OFERTA" },
    ],
  },
  {
    title: "OUTROS MODS 🛡️",
    products: [
      { image: product5, title: "Auxílio Android", price: "R$ 5,00" },
      { image: product6, title: "Wall Safe - Holograma Bypass", price: "R$ 10,00", badge: "MELHOR CUSTO" },
    ],
  },
];

const ProductSection = () => {
  return (
    <div className="px-4 pb-16 space-y-10">
      {sections.map((section) => (
        <div key={section.title}>
          <div className="mb-4">
            <span className="inline-block bg-secondary text-foreground font-display font-bold text-sm px-4 py-1.5 rounded-full border border-border">
              {section.title}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {section.products.map((product) => (
              <ProductCard key={product.title} {...product} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductSection;
